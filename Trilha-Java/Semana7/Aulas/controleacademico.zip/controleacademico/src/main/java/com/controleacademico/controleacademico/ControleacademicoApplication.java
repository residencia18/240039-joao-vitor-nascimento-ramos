package com.controleacademico.controleacademico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControleacademicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControleacademicoApplication.class, args);
	}

}
